// src/pages/settings/PrivacySettings.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ToggleRow } from "@/components/onboarding/ToggleRow";
import { Button } from "@/components/ui/button";

interface PersonConsent {
  name: string;
  role: string;
  daily_summary: boolean;
  mood_updates: boolean;
  appointments: boolean;
  medication_alerts: boolean;
  health_reports: boolean;
  vital_signs: boolean;
  cognitive_results: boolean;
  emergency_alerts: boolean;
  inactivity_alerts: boolean;
  dashboard_access: boolean;
}

const INITIAL_PEOPLE: PersonConsent[] = [
  {
    name: "Carlos García", role: "Son (Family member)",
    daily_summary: true, mood_updates: true, appointments: true,
    medication_alerts: false, health_reports: false, vital_signs: false,
    cognitive_results: false, emergency_alerts: true, inactivity_alerts: true,
    dashboard_access: false,
  },
  {
    name: "Rosa Díaz", role: "Professional carer (Caregiver)",
    daily_summary: true, mood_updates: false, appointments: true,
    medication_alerts: true, health_reports: false, vital_signs: true,
    cognitive_results: false, emergency_alerts: true, inactivity_alerts: true,
    dashboard_access: false,
  },
];

const CONSENT_ROWS: { key: keyof PersonConsent; label: string; variant?: "amber" }[] = [
  { key: "daily_summary",    label: "Daily wellbeing summary" },
  { key: "mood_updates",     label: "Mood updates" },
  { key: "appointments",     label: "Upcoming appointments" },
  { key: "medication_alerts",label: "Medication alerts" },
  { key: "health_reports",   label: "Health reports" },
  { key: "vital_signs",      label: "Vital sign data" },
  { key: "cognitive_results",label: "Cognitive session results" },
  { key: "emergency_alerts", label: "Emergency alerts", variant: "amber" },
  { key: "inactivity_alerts",label: "Inactivity alerts" },
  { key: "dashboard_access", label: "View my care dashboard" },
];

export default function PrivacySettings() {
  const [, setLocation] = useLocation();
  const [people, setPeople] = useState<PersonConsent[]>(INITIAL_PEOPLE);
  const [saving, setSaving] = useState(false);

  const update = (personIdx: number, key: keyof PersonConsent, value: boolean) => {
    setPeople((prev) => prev.map((p, i) => i === personIdx ? { ...p, [key]: value } : p));
  };

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    setSaving(false);
  };

  return (
    <PhoneFrame subtitle="Privacy & consent" showBack onBack={() => setLocation("/app/settings")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🔒 Privacy & consent</h2>
          <p className="text-xs text-gray-500 mt-1">Control what each person in your care team can see. Change any time.</p>
        </div>

        {/* Per-person consent */}
        {people.map((person, idx) => (
          <div key={person.name}>
            <p className="text-xs font-bold text-[#6b21a8] pb-1 border-b border-purple-100 mb-2">
              {person.name} — {person.role}
            </p>
            <div className="divide-y divide-purple-50">
              {CONSENT_ROWS.map(({ key, label, variant }) => (
                <ToggleRow
                  key={key}
                  title={label}
                  checked={person[key] as boolean}
                  onChange={(v) => update(idx, key, v)}
                  variant={variant}
                />
              ))}
            </div>
          </div>
        ))}

        {/* GDPR rights */}
        <div>
          <p className="text-xs font-bold text-gray-600 mb-3">Your data rights (GDPR)</p>
          <div className="flex flex-col gap-2">
            {[
              { icon: "📥", title: "Download all my data",             sub: "Full copy in JSON format (Article 20)", danger: false },
              { icon: "🚫", title: "Withdraw all consent",             sub: "Stops all data processing — VYVA will stop working", danger: false },
              { icon: "🗑️", title: "Delete my account and all data",  sub: "Permanent — cannot be undone", danger: true },
            ].map(({ icon, title, sub, danger }) => (
              <button key={title} type="button"
                className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-colors hover:bg-purple-50 ${danger ? "border-red-100" : "border-purple-100"}`}>
                <span className="text-lg flex-shrink-0">{icon}</span>
                <div className="flex-1">
                  <p className={`text-sm font-semibold ${danger ? "text-red-600" : "text-gray-900"}`}>{title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{sub}</p>
                </div>
                <span className="text-gray-300 text-sm">›</span>
              </button>
            ))}
          </div>
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
          {saving ? "Saving..." : "Save privacy settings"}
        </Button>
      </div>
    </PhoneFrame>
  );
}
