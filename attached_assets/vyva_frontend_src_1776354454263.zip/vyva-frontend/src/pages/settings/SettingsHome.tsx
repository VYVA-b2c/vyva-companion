// src/pages/settings/SettingsHome.tsx
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ChevronRight } from "lucide-react";

interface RowProps {
  icon: string;
  title: string;
  sub?: string;
  value?: string;
  onClick?: () => void;
  danger?: boolean;
}

function Row({ icon, title, sub, value, onClick, danger }: RowProps) {
  return (
    <button type="button" onClick={onClick}
      className="w-full flex items-center gap-3 px-4 py-3 border-t border-purple-50 first:border-t-0 hover:bg-purple-50/50 transition-colors text-left">
      <span className="text-lg w-6 text-center flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-semibold ${danger ? "text-red-600" : "text-gray-900"}`}>{title}</p>
        {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
      </div>
      {value && <span className="text-xs font-semibold text-[#6b21a8] flex-shrink-0">{value}</span>}
      <ChevronRight className="w-4 h-4 text-gray-300 flex-shrink-0" />
    </button>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border border-purple-100 rounded-xl overflow-hidden">
      <div className="bg-purple-50 px-4 py-2 text-[10px] font-bold text-purple-700 uppercase tracking-wider">{title}</div>
      {children}
    </div>
  );
}

export default function SettingsHome() {
  const [, setLocation] = useLocation();
  return (
    <PhoneFrame>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-xl font-bold text-gray-900">⚙️ Settings</h2>
          <p className="text-sm text-gray-500 mt-1">Manage your account, notifications, privacy, and subscription.</p>
        </div>

        <Section title="Account">
          <Row icon="👤" title="My account"              sub="Name, phone, language, password"           onClick={() => setLocation("/app/settings/account")} />
          <Row icon="🔔" title="Notifications & contact" sub="Channels, quiet hours, frequency"          onClick={() => setLocation("/app/settings/notifications")} />
        </Section>

        <Section title="Privacy">
          <Row icon="🔒" title="Privacy & consent"       sub="What your care team can see, your data rights" onClick={() => setLocation("/app/settings/privacy")} />
          <Row icon="📥" title="Download my data"        sub="Get a copy of everything VYVA holds about you" />
        </Section>

        <Section title="Subscription">
          <Row icon="💳" title="Plan & billing"          sub="Free trial · 14 days remaining"  value="Free" onClick={() => setLocation("/app/settings/subscription")} />
        </Section>

        <Section title="About">
          <Row icon="📄" title="Terms of service" />
          <Row icon="🔐" title="Privacy policy" />
          <Row icon="💬" title="Contact support" />
          <Row icon="⭐" title="Send feedback" />
          <Row icon="ℹ️" title="App version" value="1.0.0" />
        </Section>

        <Section title="Danger zone">
          <Row icon="🚪" title="Sign out"                              danger />
          <Row icon="🗑️" title="Delete my account and all data" sub="Permanent — cannot be undone" danger />
        </Section>
      </div>
    </PhoneFrame>
  );
}
