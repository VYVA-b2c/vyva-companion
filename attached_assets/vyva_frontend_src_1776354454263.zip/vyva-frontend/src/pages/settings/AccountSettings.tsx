// src/pages/settings/AccountSettings.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AccountSettings() {
  const [, setLocation] = useLocation();
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    setSaving(false);
  };

  return (
    <PhoneFrame subtitle="My account" showBack onBack={() => setLocation("/app/settings")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">👤 My account</h2>
          <p className="text-xs text-gray-500 mt-1">Update your personal details.</p>
        </div>

        {[
          { id:"full_name",       label:"Full name",                              placeholder:"", defaultValue:"María García López" },
          { id:"preferred_name",  label:"Preferred name (what VYVA calls you)",   placeholder:"", defaultValue:"María" },
        ].map(({ id, label, placeholder, defaultValue }) => (
          <div key={id} className="space-y-1.5">
            <Label htmlFor={id} className="text-xs font-bold text-gray-600">{label}</Label>
            <Input id={id} placeholder={placeholder} defaultValue={defaultValue} className="h-11 border-purple-200" />
          </div>
        ))}

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Date of birth</Label>
            <Input type="date" defaultValue="1948-03-15" className="h-11 border-purple-200" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Gender</Label>
            <Select defaultValue="female">
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="non_binary">Non-binary</SelectItem>
                <SelectItem value="prefer_not">Prefer not to say</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {[
          { id:"phone",     label:"Phone number",               type:"tel",   placeholder:"+34 612 345 678" },
          { id:"whatsapp",  label:"WhatsApp (if different)",    type:"tel",   placeholder:"Leave blank if same" },
          { id:"email",     label:"Email (optional)",           type:"email", placeholder:"maria@email.com" },
        ].map(({ id, label, type, placeholder }) => (
          <div key={id} className="space-y-1.5">
            <Label htmlFor={id} className="text-xs font-bold text-gray-600">{label}</Label>
            <Input id={id} type={type} placeholder={placeholder} className="h-11 border-purple-200" />
          </div>
        ))}

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Language</Label>
            <Select defaultValue="es">
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="de">Deutsch</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Timezone</Label>
            <Select defaultValue="madrid">
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="madrid">Europe/Madrid</SelectItem>
                <SelectItem value="berlin">Europe/Berlin</SelectItem>
                <SelectItem value="london">Europe/London</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={saving} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {saving ? "Saving..." : "Save changes"}
          </Button>
          <button className="text-xs text-red-500 py-2">Change password</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
