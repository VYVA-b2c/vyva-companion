// src/pages/settings/SubscriptionSettings.tsx
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";

const PREMIUM_FEATURES = [
  "Medication reminders + interaction checks",
  "Health coaching + nutrition",
  "Vital sign monitoring",
  "Safety agent + fall detection",
  "Concierge services",
  "Caregiver dashboard + alerts",
  "Device data integration",
  "Personalised cognitive training",
];

interface BillingStatus {
  status: string;
  tier: string;
  trial_days_remaining: number;
  trial_ends_at: string | null;
}

export default function SubscriptionSettings() {
  const [, setLocation] = useLocation();
  const [billing, setBilling] = useState<BillingStatus | null>(null);
  const [upgrading, setUpgrading] = useState(false);

  useEffect(() => {
    fetch("/api/billing/status")
      .then((r) => r.json())
      .then(setBilling)
      .catch(() => {});
  }, []);

  const handleUpgrade = async () => {
    setUpgrading(true);
    try {
      const res = await fetch("/api/billing/create-checkout", { method: "POST" });
      const { url } = await res.json();
      if (url) window.location.href = url;
    } finally {
      setUpgrading(false);
    }
  };

  const handlePortal = async () => {
    const res = await fetch("/api/billing/portal");
    const { url } = await res.json();
    if (url) window.location.href = url;
  };

  const isPremium = billing?.tier === "premium";

  return (
    <PhoneFrame subtitle="Plan & billing" showBack onBack={() => setLocation("/app/settings")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">💳 Plan & billing</h2>
        </div>

        {/* Current plan card */}
        <div className="border-2 border-[#6b21a8] rounded-xl p-4 bg-purple-50">
          <p className="text-base font-bold text-[#6b21a8]">{isPremium ? "Premium" : "Free plan"}</p>
          <p className="text-xs text-gray-500 mt-1">
            {isPremium
              ? "Full VYVA experience — all features included"
              : "Companionship, brain training, daily check-ins"}
          </p>
          {billing && !isPremium && billing.trial_days_remaining > 0 && (
            <span className="inline-block mt-2 text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">
              🕐 Trial: {billing.trial_days_remaining} days remaining
            </span>
          )}
          {billing && !isPremium && billing.trial_days_remaining === 0 && (
            <span className="inline-block mt-2 text-[10px] font-bold bg-red-100 text-red-700 px-2 py-0.5 rounded-full">
              Trial expired — upgrade to continue
            </span>
          )}
        </div>

        {/* Premium features */}
        {!isPremium && (
          <>
            <div>
              <p className="text-xs font-bold text-gray-600 mb-3">What's included in Premium</p>
              <div className="flex flex-col gap-2">
                {PREMIUM_FEATURES.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-sm text-gray-700">
                    <span className="text-green-600 font-bold flex-shrink-0">✓</span>
                    {f}
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing */}
            <div className="border border-purple-100 rounded-xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-purple-50">
                <span className="text-sm font-bold text-gray-900">Premium</span>
                <span className="text-base font-bold text-[#6b21a8]">€29 / month</span>
              </div>
              <div className="px-4 py-2.5 text-xs text-gray-500">Cancel any time. No contract.</div>
            </div>

            <Button onClick={handleUpgrade} disabled={upgrading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
              {upgrading ? "Redirecting..." : "Upgrade to Premium"}
            </Button>
            <button className="text-xs text-gray-400 text-center py-1">Restore purchase</button>
          </>
        )}

        {/* Premium — manage billing */}
        {isPremium && (
          <Button variant="outline" onClick={handlePortal} className="w-full h-12 font-bold border-[#6b21a8] text-[#6b21a8]">
            Manage billing & invoices
          </Button>
        )}
      </div>
    </PhoneFrame>
  );
}
