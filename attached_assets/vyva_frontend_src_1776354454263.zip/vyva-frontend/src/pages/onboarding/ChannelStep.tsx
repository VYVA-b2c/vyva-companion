// src/pages/onboarding/ChannelStep.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const CHANNELS = [
  {
    id: "voice_app",
    emoji: "💻",
    title: "Use the app",
    subtitle: "Talk to VYVA here by voice or text",
    badge: "Recommended",
    badgeColor: "bg-purple-100 text-purple-700",
    bg: "#ede9fe",
  },
  {
    id: "voice_outbound",
    emoji: "📞",
    title: "Receive a call from VYVA",
    subtitle: "VYVA calls you at a time you choose",
    badge: "Great for check-ins",
    badgeColor: "bg-amber-100 text-amber-700",
    bg: "#faeeda",
  },
  {
    id: "whatsapp_outbound",
    emoji: "💬",
    title: "Chat on WhatsApp",
    subtitle: "Message VYVA anytime — no new app needed",
    badge: "No new app needed",
    badgeColor: "bg-green-100 text-green-700",
    bg: "#e1f5ee",
  },
];

export default function ChannelStep() {
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<string[]>(["voice_app"]);
  const [loading, setLoading] = useState(false);

  const toggle = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const handleContinue = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/channel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ channels: selected }),
      });
      setLocation("/onboarding/consent");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="Step 2 of 3 — How you'll use VYVA" progress={40} showBack onBack={() => setLocation("/onboarding/basics")}>
      <div className="flex flex-col gap-5 px-5 py-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900">How would you like to use VYVA?</h2>
          <p className="text-sm text-gray-500 mt-1">Pick one or all. Change any time by asking VYVA.</p>
        </div>

        <div className="flex flex-col gap-3">
          {CHANNELS.map((ch) => {
            const isSelected = selected.includes(ch.id);
            return (
              <button
                key={ch.id}
                type="button"
                onClick={() => toggle(ch.id)}
                className={cn(
                  "flex items-start gap-3 p-4 rounded-xl border-2 text-left transition-all",
                  isSelected ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
                )}
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-xl"
                  style={{ background: ch.bg }}
                >
                  {ch.emoji}
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-900">{ch.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{ch.subtitle}</p>
                  <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded mt-1.5 inline-block", ch.badgeColor)}>
                    {ch.badge}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-auto pt-2">
          <Button
            onClick={handleContinue}
            disabled={selected.length === 0 || loading}
            className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40"
          >
            {loading ? "Saving..." : "Continue"}
          </Button>
        </div>
      </div>
    </PhoneFrame>
  );
}
