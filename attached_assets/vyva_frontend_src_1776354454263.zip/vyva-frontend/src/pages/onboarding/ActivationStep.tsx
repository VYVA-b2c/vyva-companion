// src/pages/onboarding/ActivationStep.tsx
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";

export default function ActivationStep() {
  const [, setLocation] = useLocation();

  return (
    <PhoneFrame subtitle="Ready!" progress={100}>
      <div className="flex flex-col items-center gap-5 px-5 py-10 text-center">
        {/* Success icon */}
        <div className="w-16 h-16 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center text-3xl">
          ✅
        </div>

        <div>
          <h2 className="text-2xl font-bold text-gray-900">You're all set!</h2>
          <p className="text-sm text-gray-500 mt-3 leading-relaxed max-w-xs">
            VYVA is ready to meet you. Complete your profile to unlock more features —
            or start now and VYVA will ask the rest naturally over time.
          </p>
        </div>

        <div className="w-full flex flex-col gap-3 mt-4">
          <Button
            onClick={() => setLocation("/onboarding/profile")}
            className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]"
          >
            Complete my profile
          </Button>
          <Button
            variant="outline"
            onClick={() => setLocation("/app")}
            className="w-full h-12 text-base font-bold border-[#6b21a8] text-[#6b21a8] hover:bg-purple-50"
          >
            Talk to VYVA now
          </Button>
          <p className="text-xs text-gray-400">
            You can always add more later by telling VYVA
          </p>
        </div>
      </div>
    </PhoneFrame>
  );
}
