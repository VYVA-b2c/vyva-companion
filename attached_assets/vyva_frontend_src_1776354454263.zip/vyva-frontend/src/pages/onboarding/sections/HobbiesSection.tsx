// src/pages/onboarding/sections/HobbiesSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ChipSelector } from "@/components/onboarding/ChipSelector";
import { Button } from "@/components/ui/button";

const HOBBY_GROUPS = [
  { label: "Sports & activity",  items: ["Walking","Swimming","Cycling","Yoga / Pilates","Golf","Football","Tennis","Bowls","Dancing"] },
  { label: "Creative",           items: ["Painting / Drawing","Knitting / Sewing","Photography","Pottery","Writing","Singing / Choir"] },
  { label: "Mind & games",       items: ["Reading","Chess","Crosswords","Puzzles","Card games","Board games"] },
  { label: "Nature",             items: ["Gardening","Bird watching","Fishing"] },
  { label: "Culture & social",   items: ["Music","Theatre / Opera","Cinema / TV","History","Travel","Volunteering","Faith community","Book club","Cooking / Baking"] },
  { label: "Learning",           items: ["Languages","Local history","Online courses","Computers / Tech"] },
];

export default function HobbiesSection() {
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/hobbies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hobbies: selected }),
      });
      setLocation("/onboarding/complete/hobbies");
    } finally { setLoading(false); }
  };

  return (
    <PhoneFrame subtitle="⭐ Hobbies & interests" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">⭐ Hobbies & interests</h2>
          <p className="text-xs text-gray-500 mt-1">Select everything you enjoy. VYVA uses these to personalise your daily conversations.</p>
        </div>

        {HOBBY_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="text-xs font-bold text-gray-600 mb-2">{group.label}</p>
            <ChipSelector
              options={group.items}
              selected={selected.filter((s) => group.items.includes(s))}
              onChange={(newSel) => {
                const others = selected.filter((s) => !group.items.includes(s));
                setSelected([...others, ...newSel]);
              }}
            />
          </div>
        ))}

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save hobbies & interests"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
