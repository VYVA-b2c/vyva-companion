// src/pages/onboarding/sections/CognitiveSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CognitiveSection() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    memory_difficulties: "none",
    cognitive_diagnosis: "none",
    session_length_mins: 15,
    training_time: "morning",
    pace: "normal",
    variety: "variety",
    communication_style: "standard",
  });
  const [loading, setLoading] = useState(false);

  const set = (field: string, value: string | number) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/cognitive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setLocation("/onboarding/complete/cognitive");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="🧠 Cognitive profile" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🧠 Cognitive profile</h2>
          <p className="text-xs text-gray-500 mt-1">Helps VYVA adjust how it communicates and personalise brain training sessions.</p>
        </div>

        <div className="bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-3 py-2 text-xs text-purple-700">
          This information is never shared with anyone unless you explicitly enable it.
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Memory difficulties</Label>
            <Select defaultValue="none" onValueChange={(v) => set("memory_difficulties", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="mild">Mild</SelectItem>
                <SelectItem value="moderate">Moderate</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Diagnosis (if any)</Label>
            <Select defaultValue="none" onValueChange={(v) => set("cognitive_diagnosis", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="mci">MCI</SelectItem>
                <SelectItem value="early_dementia">Early dementia</SelectItem>
                <SelectItem value="alzheimers">Alzheimer's</SelectItem>
                <SelectItem value="parkinsons">Parkinson's</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Session length</Label>
            <Select defaultValue="15" onValueChange={(v) => set("session_length_mins", parseInt(v))}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 min</SelectItem>
                <SelectItem value="10">10 min</SelectItem>
                <SelectItem value="15">15 min</SelectItem>
                <SelectItem value="20">20 min</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Best time of day</Label>
            <Select defaultValue="morning" onValueChange={(v) => set("training_time", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="morning">Morning</SelectItem>
                <SelectItem value="afternoon">Afternoon</SelectItem>
                <SelectItem value="no_preference">No preference</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Pace</Label>
            <Select defaultValue="normal" onValueChange={(v) => set("pace", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="slower">Slower</SelectItem>
                <SelectItem value="very_slow">Very slow</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Exercises</Label>
            <Select defaultValue="variety" onValueChange={(v) => set("variety", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="variety">Prefer variety</SelectItem>
                <SelectItem value="repeating">Enjoy repeating</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">VYVA communication style</Label>
          <Select defaultValue="standard" onValueChange={(v) => set("communication_style", v)}>
            <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">Standard</SelectItem>
              <SelectItem value="simpler">Simpler language</SelectItem>
              <SelectItem value="very_simple">Very simple + more repetition</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save cognitive profile"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
