// src/pages/onboarding/sections/DevicesSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const PLATFORMS = [
  { id: "phone_camera", emoji: "📷", name: "Phone camera (VitalLens)", sub: "Built-in · HR · Breathing rate · HRV", connection: "built_in", alwaysActive: true },
  { id: "apple_health", emoji: "🍎", name: "Apple Health",             sub: "HR · SpO2 · Steps · Sleep · ECG · Weight", connection: "apple_health" },
  { id: "google_health",emoji: "🤖", name: "Google Health Connect",    sub: "HR · SpO2 · Steps · Sleep · Weight", connection: "google_health_connect" },
  { id: "fitbit",       emoji: "🟣", name: "Fitbit / Garmin / Withings", sub: "Connect via your device app account", connection: "fitbit" },
];

const INDIVIDUAL_DEVICES = [
  { type: "smartwatch",    emoji: "⌚", label: "Smartwatch" },
  { type: "bp_monitor",   emoji: "🩺", label: "BP monitor" },
  { type: "glucometer",   emoji: "💉", label: "Glucometer" },
  { type: "smart_scales", emoji: "⚖️", label: "Scales" },
  { type: "thermometer",  emoji: "🌡️", label: "Thermometer" },
  { type: "smart_ring",   emoji: "💍", label: "Smart ring" },
  { type: "peak_flow_meter", emoji: "🫁", label: "Peak flow" },
  { type: "bed_sensor",   emoji: "🛏️", label: "Bed sensor*", comingSoon: true },
];

export default function DevicesSection() {
  const [, setLocation] = useLocation();
  const [connectedPlatforms, setConnectedPlatforms] = useState<string[]>(["phone_camera"]);
  const [connectedDevices, setConnectedDevices] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const togglePlatform = (id: string, alwaysActive?: boolean) => {
    if (alwaysActive) return;
    setConnectedPlatforms((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleDevice = (type: string) => {
    setConnectedDevices((prev) =>
      prev.includes(type) ? prev.filter((x) => x !== type) : [...prev, type]
    );
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const devices = [
        ...connectedPlatforms.map((id) => {
          const p = PLATFORMS.find((pl) => pl.id === id)!;
          return { type: p.id === "phone_camera" ? "phone_camera" : "smartwatch", connection_method: p.connection, status: "connected", data_metrics: [] };
        }),
        ...connectedDevices.map((type) => ({
          type, connection_method: "bluetooth_direct", status: "connected", data_metrics: [],
        })),
      ];
      await fetch("/api/onboarding/section/devices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ devices }),
      });
      setLocation("/onboarding/complete/devices");
    } finally { setLoading(false); }
  };

  return (
    <PhoneFrame subtitle="📡 Devices & sensors" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">📡 Devices & sensors</h2>
          <p className="text-xs text-gray-500 mt-1">Connect devices so VYVA reads real health data before triage or symptom reports.</p>
        </div>

        <div className="bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-3 py-2 text-xs text-purple-700">
          Data from your devices is used only for VYVA to give you better guidance. It is never sold or shared without your consent.
        </div>

        <div>
          <p className="text-xs font-bold text-gray-600 mb-2">Health platforms</p>
          <div className="flex flex-col gap-2">
            {PLATFORMS.map((p) => {
              const isConnected = connectedPlatforms.includes(p.id);
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => togglePlatform(p.id, p.alwaysActive)}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-lg border text-left transition-all",
                    isConnected ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
                  )}
                >
                  <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-lg flex-shrink-0", isConnected ? "bg-purple-100" : "bg-gray-100")}>
                    {p.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-gray-900">{p.name}</p>
                    <p className="text-[10px] text-gray-500">{p.sub}</p>
                  </div>
                  <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded flex-shrink-0",
                    isConnected ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                  )}>
                    {isConnected ? (p.alwaysActive ? "Active" : "Connected") : "Connect"}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <p className="text-xs font-bold text-gray-600 mb-2">Individual devices</p>
          <div className="grid grid-cols-4 gap-2">
            {INDIVIDUAL_DEVICES.map((d) => {
              const isConnected = connectedDevices.includes(d.type);
              return (
                <button
                  key={d.type}
                  type="button"
                  disabled={d.comingSoon}
                  onClick={() => !d.comingSoon && toggleDevice(d.type)}
                  className={cn(
                    "flex flex-col items-center py-3 px-1 rounded-lg border text-center transition-all",
                    d.comingSoon ? "opacity-40 cursor-default border-purple-100 bg-white" :
                    isConnected ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
                  )}
                >
                  <span className="text-xl mb-1">{d.emoji}</span>
                  <span className="text-[9px] text-gray-500 leading-tight">{d.label.replace("*", "")}</span>
                </button>
              );
            })}
          </div>
          <p className="text-[10px] text-gray-400 text-center mt-1">* Coming soon</p>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save devices"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
