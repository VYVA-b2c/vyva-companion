// src/pages/onboarding/sections/DietSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ChipSelector } from "@/components/onboarding/ChipSelector";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const DIET_OPTIONS = [
  "Vegetarian","Vegan","Halal","Kosher","No pork","No shellfish",
  "Gluten-free","Dairy-free","Diabetic diet","Low salt","Low potassium","No restrictions",
];

export default function DietSection() {
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/diet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ preferences: selected, notes }),
      });
      setLocation("/onboarding/complete/diet");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="🥗 Dietary preferences" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🥗 Dietary preferences</h2>
          <p className="text-xs text-gray-500 mt-1">Select everything that applies. Used by VYVA to personalise nutrition coaching.</p>
        </div>

        <ChipSelector options={DIET_OPTIONS} selected={selected} onChange={setSelected} />

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Other dietary notes (optional)</Label>
          <textarea
            className="w-full border border-purple-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#6b21a8] resize-none"
            rows={3}
            placeholder="e.g. soft foods only, texture modified, low fibre..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save dietary preferences"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
