// src/pages/onboarding/sections/CareTeamFlow.tsx
// 4-step flow: Who → Details → Consent → Invite → Done
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ToggleRow } from "@/components/onboarding/ToggleRow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

type Role = "family" | "carer" | "doctor";
type InviteChannel = "whatsapp" | "sms";
type Step = 1 | 2 | 3 | 4 | 5;

interface PersonForm {
  name: string;
  relationship: string;
  phone: string;
  whatsapp: string;
  email: string;
}

interface ConsentState {
  daily_summary: boolean;
  mood_updates: boolean;
  appointments: boolean;
  medication_alerts: boolean;
  health_reports: boolean;
  vital_signs: boolean;
  cognitive_results: boolean;
  emergency_alerts: boolean;
  inactivity_alerts: boolean;
  dashboard_access: boolean;
}

const defaultConsent = (role: Role): ConsentState => ({
  daily_summary:       true,
  mood_updates:        role !== "doctor",
  appointments:        true,
  medication_alerts:   role === "carer",
  health_reports:      role === "doctor",
  vital_signs:         role === "carer" || role === "doctor",
  cognitive_results:   false,
  emergency_alerts:    true,
  inactivity_alerts:   role !== "doctor",
  dashboard_access:    false,
});

const StepDots = ({ current }: { current: number }) => (
  <div className="flex items-center gap-1.5 mb-4">
    {[1,2,3,4].map((n) => (
      <div key={n} className={cn(
        "h-2 rounded-full transition-all",
        n < current ? "w-2 bg-[#c9890a]" :
        n === current ? "w-5 bg-[#6b21a8]" : "w-2 bg-purple-100"
      )} />
    ))}
    <span className="text-[10px] text-gray-400 ml-1">Step {current} of 4</span>
  </div>
);

export default function CareTeamFlow() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<Step>(1);
  const [role, setRole] = useState<Role>("family");
  const [person, setPerson] = useState<PersonForm>({ name:"", relationship:"", phone:"", whatsapp:"", email:"" });
  const [consent, setConsent] = useState<ConsentState>(defaultConsent("family"));
  const [inviteChannel, setInviteChannel] = useState<InviteChannel>("whatsapp");
  const [loading, setLoading] = useState(false);

  const setP = (f: keyof PersonForm, v: string) => setPerson((p) => ({ ...p, [f]: v }));
  const setC = (f: keyof ConsentState, v: boolean) => setConsent((p) => ({ ...p, [f]: v }));

  const selectRole = (r: Role) => {
    setRole(r);
    setConsent(defaultConsent(r));
  };

  const handleSendInvite = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/careteam", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, person, consent, invite_channel: inviteChannel }),
      });
      setStep(5);
    } finally { setLoading(false); }
  };

  const ROLE_OPTIONS = [
    { id: "family" as Role, emoji: "👨‍👩‍👧", title: "Family member or friend", sub: "Son, daughter, spouse, sibling, friend, neighbour. Gets wellbeing summaries — you control the detail.", bg: "#ede9fe" },
    { id: "carer"  as Role, emoji: "👩‍⚕️", title: "Caregiver",                 sub: "Professional or primary carer. Can receive safety, medication, and health alerts.",              bg: "#e1f5ee" },
    { id: "doctor" as Role, emoji: "👨‍⚕️", title: "Doctor or specialist",        sub: "GP, cardiologist, pharmacist. Can view health reports when you enable it.",                      bg: "#faeeda" },
  ];

  /* ── STEP 1 — Who to add ── */
  if (step === 1) return (
    <PhoneFrame subtitle="👥 Care team — step 1 of 4" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">👥 Add someone to your care team</h2>
          <p className="text-xs text-gray-500 mt-1">You decide exactly what each person can see. Nothing is shared until you confirm.</p>
        </div>

        <div className="bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-3 py-2 text-xs text-purple-700">
          All sharing is under your control. You can change or remove access at any time in Settings → Privacy & consent.
        </div>

        <div className="flex flex-col gap-3">
          {ROLE_OPTIONS.map((opt) => (
            <button key={opt.id} type="button" onClick={() => selectRole(opt.id)}
              className={cn("flex items-start gap-3 p-4 rounded-xl border-2 text-left transition-all",
                role === opt.id ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
              )}>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-xl flex-shrink-0" style={{ background: opt.bg }}>{opt.emoji}</div>
              <div>
                <p className="text-sm font-bold text-gray-900">{opt.title}</p>
                <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{opt.sub}</p>
              </div>
            </button>
          ))}
        </div>

        <Button onClick={() => setStep(2)} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">Continue</Button>
      </div>
    </PhoneFrame>
  );

  /* ── STEP 2 — Their details ── */
  if (step === 2) return (
    <PhoneFrame subtitle="👥 Care team — step 2 of 4" showBack onBack={() => setStep(1)}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <StepDots current={2} />
        <div>
          <h2 className="text-lg font-bold text-gray-900">About them</h2>
          <p className="text-xs text-gray-500 mt-1">Tell us who you're adding.</p>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Their full name</Label>
          <Input placeholder="e.g. Carlos García" value={person.name} onChange={(e) => setP("name", e.target.value)} className="h-11 border-purple-200" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Your relationship to them</Label>
          <Select onValueChange={(v) => setP("relationship", v)}>
            <SelectTrigger className="h-11 border-purple-200"><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>
              {["Son","Daughter","Spouse / Partner","Sibling","Friend","Neighbour","Professional carer","GP","Specialist doctor","Other"].map((r) => (
                <SelectItem key={r} value={r}>{r}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Their phone number</Label>
          <Input type="tel" placeholder="+34 698 765 432" value={person.phone} onChange={(e) => setP("phone", e.target.value)} className="h-11 border-purple-200" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Their WhatsApp (if different)</Label>
          <Input type="tel" placeholder="Leave blank if same as phone" value={person.whatsapp} onChange={(e) => setP("whatsapp", e.target.value)} className="h-11 border-purple-200" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Their email (optional)</Label>
          <Input type="email" placeholder="carlos@email.com" value={person.email} onChange={(e) => setP("email", e.target.value)} className="h-11 border-purple-200" />
        </div>

        <Button onClick={() => setStep(3)} disabled={!person.name.trim() || !person.phone.trim()} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40">
          Continue
        </Button>
      </div>
    </PhoneFrame>
  );

  /* ── STEP 3 — Consent ── */
  if (step === 3) return (
    <PhoneFrame subtitle="👥 Care team — step 3 of 4" showBack onBack={() => setStep(2)}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <StepDots current={3} />
        <div>
          <h2 className="text-lg font-bold text-gray-900">What can {person.name || "they"} see?</h2>
          <p className="text-xs text-gray-500 mt-1">You decide. Toggle on what you're comfortable sharing. Change any time in Settings.</p>
        </div>

        {/* Person card */}
        <div className="flex items-center gap-3 border-2 border-[#6b21a8] rounded-xl p-3 bg-purple-50">
          <div className="w-10 h-10 rounded-full bg-[#6b21a8] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
            {person.name.split(" ").map((n) => n[0]).join("").slice(0,2).toUpperCase() || "?"}
          </div>
          <div>
            <p className="text-sm font-bold text-gray-900">{person.name || "—"}</p>
            <p className="text-[10px] text-purple-600 font-semibold capitalize">{role === "family" ? "Family member" : role === "carer" ? "Caregiver" : "Doctor"}</p>
            <p className="text-[10px] text-gray-500">{person.relationship} · {person.phone}</p>
          </div>
        </div>

        {/* Updates & summaries */}
        <div className="border border-purple-100 rounded-xl overflow-hidden">
          <div className="bg-purple-50 px-3 py-2 text-[10px] font-bold text-purple-700 uppercase tracking-wide">💬 Updates & summaries</div>
          <div className="px-3 divide-y divide-purple-50">
            <ToggleRow title="Daily wellbeing summary" description="A short daily update — how you're feeling, whether you spoke to VYVA" checked={consent.daily_summary} onChange={(v) => setC("daily_summary", v)} />
            <ToggleRow title="Mood updates" description="If VYVA detects you're feeling low or anxious" checked={consent.mood_updates} onChange={(v) => setC("mood_updates", v)} />
            <ToggleRow title="Upcoming appointments" description="Doctor appointments and important reminders" checked={consent.appointments} onChange={(v) => setC("appointments", v)} />
          </div>
        </div>

        {/* Health information */}
        <div className="border border-purple-100 rounded-xl overflow-hidden">
          <div className="bg-purple-50 px-3 py-2 text-[10px] font-bold text-purple-700 uppercase tracking-wide">🏥 Health information</div>
          <div className="px-3 divide-y divide-purple-50">
            <ToggleRow title="Medication alerts" description="Notified if you miss a dose" checked={consent.medication_alerts} onChange={(v) => setC("medication_alerts", v)} />
            <ToggleRow title="Health reports" description="Detailed health summaries including conditions and vitals" checked={consent.health_reports} onChange={(v) => setC("health_reports", v)} />
            <ToggleRow title="Vital sign data" description="Heart rate, blood pressure, oxygen levels from your devices" checked={consent.vital_signs} onChange={(v) => setC("vital_signs", v)} />
            <ToggleRow title="Cognitive session results" description="How you're doing in brain training sessions" checked={consent.cognitive_results} onChange={(v) => setC("cognitive_results", v)} />
          </div>
        </div>

        {/* Safety alerts */}
        <div className="border border-purple-100 rounded-xl overflow-hidden">
          <div className="bg-purple-50 px-3 py-2 text-[10px] font-bold text-purple-700 uppercase tracking-wide">🆘 Safety alerts</div>
          <div className="px-3 divide-y divide-purple-50">
            <ToggleRow title="Emergency alerts" description="Called immediately if VYVA detects a fall or emergency" checked={consent.emergency_alerts} onChange={(v) => setC("emergency_alerts", v)} variant="amber" />
            <ToggleRow title="Inactivity alerts" description="If VYVA hasn't heard from you for an unusual amount of time" checked={consent.inactivity_alerts} onChange={(v) => setC("inactivity_alerts", v)} />
          </div>
        </div>

        {/* Dashboard */}
        <div className="border border-purple-100 rounded-xl overflow-hidden">
          <div className="bg-purple-50 px-3 py-2 text-[10px] font-bold text-purple-700 uppercase tracking-wide">📊 Dashboard access</div>
          <div className="px-3">
            <ToggleRow title="View my care dashboard" description={`${person.name || "They"} can log in to view a summary of your health and activities`} checked={consent.dashboard_access} onChange={(v) => setC("dashboard_access", v)} />
          </div>
        </div>

        <p className="text-[10px] text-gray-400 text-center">Change these any time in Settings → Privacy & consent</p>

        <Button onClick={() => setStep(4)} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
          Confirm and continue
        </Button>
      </div>
    </PhoneFrame>
  );

  /* ── STEP 4 — Send invite ── */
  if (step === 4) return (
    <PhoneFrame subtitle="👥 Care team — step 4 of 4" showBack onBack={() => setStep(3)}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <StepDots current={4} />
        <div>
          <h2 className="text-lg font-bold text-gray-900">Invite {person.name || "them"} to connect</h2>
          <p className="text-xs text-gray-500 mt-1">
            We'll send {person.name || "them"} a message explaining VYVA and what you've chosen to share.
            They must accept before anything is visible.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          {([
            { id: "whatsapp" as InviteChannel, emoji: "💬", title: "WhatsApp message", sub: `To ${person.whatsapp || person.phone}`, bg: "#e1f5ee" },
            { id: "sms"      as InviteChannel, emoji: "📱", title: "SMS text message",  sub: `To ${person.phone}`,                   bg: "#e6f1fb" },
          ]).map((opt) => (
            <button key={opt.id} type="button" onClick={() => setInviteChannel(opt.id)}
              className={cn("flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all",
                inviteChannel === opt.id ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
              )}>
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-xl flex-shrink-0" style={{ background: opt.bg }}>{opt.emoji}</div>
              <div>
                <p className="text-sm font-bold text-gray-900">{opt.title}</p>
                <p className="text-xs text-gray-500">{opt.sub}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Message preview */}
        <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-3">
          <p className="text-[9px] font-bold text-green-700 uppercase tracking-wider mb-2">Message preview</p>
          <p className="text-xs text-green-800 leading-relaxed">
            Hi <strong>{person.name || "there"}</strong> — your family member has set up VYVA, an AI companion
            that supports their daily wellbeing. They'd like to share daily updates with you.
            Tap the link below to accept and create your free account.
            <br /><br />
            <span className="text-teal-700 font-semibold">vyva.ai/join/abc123 →</span>
          </p>
        </div>

        <Button onClick={handleSendInvite} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
          {loading ? "Sending..." : "Send invitation"}
        </Button>
      </div>
    </PhoneFrame>
  );

  /* ── STEP 5 — Done ── */
  return (
    <PhoneFrame subtitle="👥 Care team">
      <div className="flex flex-col items-center gap-4 px-4 py-10 text-center">
        <div className="w-14 h-14 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center text-3xl">✅</div>
        <div>
          <h2 className="text-xl font-bold text-gray-900">{person.name} has been invited</h2>
          <p className="text-sm text-gray-500 mt-2 leading-relaxed">
            Once {person.name} accepts, they'll see only what you've chosen to share.
            You'll be notified when they join.
          </p>
        </div>

        {/* Person card */}
        <div className="w-full flex items-center gap-3 border-2 border-[#6b21a8] rounded-xl p-3 bg-purple-50">
          <div className="w-10 h-10 rounded-full bg-[#6b21a8] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
            {person.name.split(" ").map((n) => n[0]).join("").slice(0,2).toUpperCase()}
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-bold text-gray-900">{person.name}</p>
            <p className="text-[10px] text-purple-600 font-semibold">{person.relationship}</p>
            <p className="text-[10px] text-gray-500">Invitation sent · pending acceptance</p>
          </div>
          <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full flex-shrink-0">Pending</span>
        </div>

        <div className="w-full bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-3 py-2 text-xs text-purple-700 text-left">
          {person.name} cannot see anything until they accept. If they don't accept within 7 days, the link expires automatically.
        </div>

        <div className="w-full flex flex-col gap-3">
          <Button onClick={() => { setStep(1); setPerson({ name:"", relationship:"", phone:"", whatsapp:"", email:"" }); }} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            Add another person
          </Button>
          <Button variant="outline" onClick={() => setLocation("/onboarding/complete/careteam")} className="w-full h-12 font-bold border-[#6b21a8] text-[#6b21a8]">
            Done — back to profile
          </Button>
        </div>
      </div>
    </PhoneFrame>
  );
}
