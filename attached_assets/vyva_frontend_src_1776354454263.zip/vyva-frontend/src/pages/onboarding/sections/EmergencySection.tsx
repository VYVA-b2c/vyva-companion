// src/pages/onboarding/sections/EmergencySection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function EmergencySection() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    name: "", relationship: "",
    primary_phone: "", secondary_phone: "", address: "",
  });
  const [loading, setLoading] = useState(false);
  const set = (f: string, v: string) => setForm((p) => ({ ...p, [f]: v }));

  const isValid = form.name.trim() && form.primary_phone.trim();

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/emergency", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setLocation("/onboarding/complete/emergency");
    } finally { setLoading(false); }
  };

  return (
    <PhoneFrame subtitle="🆘 Emergency contact" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🆘 Emergency contact</h2>
          <p className="text-xs text-gray-500 mt-1">Called immediately if VYVA cannot reach you. Must be reachable 24/7.</p>
        </div>

        <div className="bg-red-50 border-l-2 border-red-400 rounded-lg px-3 py-2 text-xs text-red-700">
          This person can be the same as your caregiver. Their number is shared with emergency services only when needed.
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Full name</Label>
          <Input placeholder="Name of emergency contact" value={form.name} onChange={(e) => set("name", e.target.value)} className="h-11 border-purple-200" />
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Relationship to you</Label>
          <Input placeholder="e.g. Daughter, Neighbour, Carer" value={form.relationship} onChange={(e) => set("relationship", e.target.value)} className="h-11 border-purple-200" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Primary phone (24/7)</Label>
            <Input type="tel" placeholder="Always reachable" value={form.primary_phone} onChange={(e) => set("primary_phone", e.target.value)} className="h-11 border-purple-200" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Secondary phone</Label>
            <Input type="tel" placeholder="Backup number" value={form.secondary_phone} onChange={(e) => set("secondary_phone", e.target.value)} className="h-11 border-purple-200" />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Their address (for emergency services)</Label>
          <Input placeholder="If different from yours" value={form.address} onChange={(e) => set("address", e.target.value)} className="h-11 border-purple-200" />
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={!isValid || loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40">
            {loading ? "Saving..." : "Save emergency contact"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
