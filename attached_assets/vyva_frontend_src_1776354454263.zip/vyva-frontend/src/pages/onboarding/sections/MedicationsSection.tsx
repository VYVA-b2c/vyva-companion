// src/pages/onboarding/sections/MedicationsSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  times: string;
  with_food: string;
  prescribed_by: string;
}

const emptyMed = (): Medication => ({
  name: "", dosage: "", frequency: "", times: "", with_food: "", prescribed_by: "",
});

export default function MedicationsSection() {
  const [, setLocation] = useLocation();
  const [meds, setMeds] = useState<Medication[]>([emptyMed()]);
  const [loading, setLoading] = useState(false);

  const updateMed = (idx: number, field: keyof Medication, value: string) => {
    setMeds((prev) => prev.map((m, i) => i === idx ? { ...m, [field]: value } : m));
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/medications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ medications: meds.filter((m) => m.name.trim()) }),
      });
      setLocation("/onboarding/complete/medications");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="💊 Medications" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-5 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">💊 Medications</h2>
          <p className="text-xs text-gray-500 mt-1">All optional — skip any field you prefer not to fill in.</p>
        </div>

        {meds.map((med, idx) => (
          <div key={idx} className="border border-purple-100 rounded-xl p-4 bg-white flex flex-col gap-3">
            {meds.length > 1 && (
              <p className="text-[10px] font-bold text-purple-600">Medication {idx + 1}</p>
            )}
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-gray-600">Medication name</Label>
              <Input placeholder="e.g. Metformin" value={med.name} onChange={(e) => updateMed(idx, "name", e.target.value)} className="h-11 border-purple-200" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-600">Dosage</Label>
                <Input placeholder="e.g. 500mg" value={med.dosage} onChange={(e) => updateMed(idx, "dosage", e.target.value)} className="h-11 border-purple-200" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-600">Frequency</Label>
                <Select onValueChange={(v) => updateMed(idx, "frequency", v)}>
                  <SelectTrigger className="h-11 border-purple-200"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="once_daily">Once daily</SelectItem>
                    <SelectItem value="twice_daily">Twice daily</SelectItem>
                    <SelectItem value="three_daily">3x daily</SelectItem>
                    <SelectItem value="as_needed">As needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-600">Time(s)</Label>
                <Input placeholder="e.g. 08:00, 20:00" value={med.times} onChange={(e) => updateMed(idx, "times", e.target.value)} className="h-11 border-purple-200" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-600">With food?</Label>
                <Select onValueChange={(v) => updateMed(idx, "with_food", v)}>
                  <SelectTrigger className="h-11 border-purple-200"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="with_food">With food</SelectItem>
                    <SelectItem value="without_food">Without food</SelectItem>
                    <SelectItem value="doesnt_matter">Doesn't matter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-gray-600">Prescribed by</Label>
              <Input placeholder="GP or specialist name" value={med.prescribed_by} onChange={(e) => updateMed(idx, "prescribed_by", e.target.value)} className="h-11 border-purple-200" />
            </div>
          </div>
        ))}

        <button
          type="button"
          onClick={() => setMeds((prev) => [...prev, emptyMed()])}
          className="text-sm font-bold text-[#6b21a8] text-left"
        >
          + Add another medication
        </button>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save medications"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
