// src/pages/onboarding/sections/GPSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function GPSection() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    gp_name: "", practice_name: "", practice_address: "",
    practice_phone: "", practice_email: "", out_of_hours: "",
  });
  const [loading, setLoading] = useState(false);
  const set = (f: string, v: string) => setForm((p) => ({ ...p, [f]: v }));

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/gp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setLocation("/onboarding/complete/gp");
    } finally { setLoading(false); }
  };

  return (
    <PhoneFrame subtitle="🏥 GP / Doctor" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🏥 GP / Doctor</h2>
          <p className="text-xs text-gray-500 mt-1">Helps VYVA assist with appointment prep and health referrals.</p>
        </div>
        <div className="border border-purple-100 rounded-xl p-4 bg-white flex flex-col gap-3">
          <p className="text-[10px] font-bold text-purple-600">Primary GP</p>
          {[
            { field: "gp_name",          label: "GP full name",          placeholder: "e.g. Dr. Ana Martínez" },
            { field: "practice_name",    label: "Practice / Clinic name", placeholder: "e.g. Centro de Salud Norte" },
            { field: "practice_address", label: "Practice address",       placeholder: "Full street address" },
            { field: "practice_phone",   label: "Practice phone",         placeholder: "+34 980...", type: "tel" },
            { field: "practice_email",   label: "Practice email",         placeholder: "surgery@nhs.net", type: "email" },
            { field: "out_of_hours",     label: "Out-of-hours / emergency number", placeholder: "e.g. 112 or 116 117", type: "tel" },
          ].map(({ field, label, placeholder, type = "text" }) => (
            <div key={field} className="space-y-1.5">
              <Label className="text-xs font-bold text-gray-600">{label}</Label>
              <Input type={type} placeholder={placeholder} value={(form as any)[field]} onChange={(e) => set(field, e.target.value)} className="h-11 border-purple-200" />
            </div>
          ))}
        </div>
        <button className="text-sm font-bold text-[#6b21a8] text-left">+ Add a specialist (cardiologist, neurologist...)</button>
        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save GP details"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
