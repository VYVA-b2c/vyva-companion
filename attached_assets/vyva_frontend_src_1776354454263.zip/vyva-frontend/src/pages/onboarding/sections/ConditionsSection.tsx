// src/pages/onboarding/sections/ConditionsSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { CategoryFilterBar } from "@/components/onboarding/CategoryFilterBar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { id: "all",        label: "All" },
  { id: "heart",      label: "🫀 Heart" },
  { id: "metabolic",  label: "🩸 Metabolic" },
  { id: "respiratory",label: "🫁 Respiratory" },
  { id: "musculo",    label: "🦴 Joints" },
  { id: "neuro",      label: "🧠 Neurological" },
  { id: "mental",     label: "💙 Mental health" },
  { id: "cancer",     label: "🎗️ Cancer" },
  { id: "kidney",     label: "🫘 Kidney" },
  { id: "digestive",  label: "🫃 Digestive" },
  { id: "sensory",    label: "👁️ Sensory" },
  { id: "other",      label: "+ Other" },
];

const CONDITION_GROUPS: { cat: string; label: string; items: string[] }[] = [
  { cat: "heart",      label: "Heart & circulation",     items: ["Hypertension","High cholesterol","Heart failure","Atrial fibrillation","Coronary artery disease","Heart attack (history)","Stroke (history)","Pacemaker / ICD","Deep vein thrombosis","Peripheral artery disease","Anaemia"] },
  { cat: "metabolic",  label: "Metabolic & hormonal",    items: ["Diabetes Type 1","Diabetes Type 2","Pre-diabetes","Hypothyroidism","Hyperthyroidism","Osteoporosis","Vitamin D deficiency","Gout","Obesity","Metabolic syndrome"] },
  { cat: "respiratory",label: "Respiratory",             items: ["COPD","Asthma","Sleep apnoea","Pulmonary fibrosis","Chronic bronchitis","Emphysema","Pleural effusion"] },
  { cat: "musculo",    label: "Joints, bones & muscles", items: ["Osteoarthritis","Rheumatoid arthritis","Psoriatic arthritis","Fibromyalgia","Back pain (chronic)","Hip replacement","Knee replacement","Spinal stenosis","Muscle weakness","Lupus"] },
  { cat: "neuro",      label: "Neurological",            items: ["Dementia","Alzheimer's","Parkinson's disease","Epilepsy","Multiple sclerosis","Peripheral neuropathy","Tremors","Migraine (chronic)","Motor neurone disease","Balance disorder"] },
  { cat: "mental",     label: "Mental health",           items: ["Depression","Anxiety","Bipolar disorder","PTSD","OCD","Loneliness / isolation","Grief / bereavement","Sleep disorder / insomnia"] },
  { cat: "cancer",     label: "Cancer & oncology",       items: ["Active cancer treatment","Cancer — in remission","Cancer — monitoring","Post-surgical recovery","Lymphoedema"] },
  { cat: "kidney",     label: "Kidney & urinary",        items: ["Chronic kidney disease","Kidney stones","Urinary incontinence","Enlarged prostate (BPH)","Recurrent UTIs","Dialysis"] },
  { cat: "digestive",  label: "Digestive & gut",         items: ["IBS","Crohn's disease","Ulcerative colitis","GERD / Acid reflux","Coeliac disease","Diverticular disease","Liver disease","Gallstones","Constipation (chronic)"] },
  { cat: "sensory",    label: "Sensory & skin",          items: ["Vision impairment","Hearing loss","Glaucoma","Cataracts","Macular degeneration","Tinnitus","Eczema / Psoriasis","Diabetic retinopathy"] },
  { cat: "other",      label: "Other",                   items: ["Falls (recurrent)","Wound / ulcer (ongoing)","Chronic fatigue","Post-COVID / long COVID","Autoimmune condition","Transplant recipient","Blood disorder","Skin condition"] },
];

const MOBILITY_OPTIONS = [
  { value: "independent",           label: "🚶 Fully independent",       sub: "No aids needed" },
  { value: "stick_or_frame",        label: "🦯 Uses a stick or frame",    sub: "" },
  { value: "wheelchair_part_time",  label: "♿ Wheelchair (part-time)",   sub: "For longer distances" },
  { value: "wheelchair_full_time",  label: "♿ Wheelchair (full-time)",   sub: "Primary mode of movement" },
  { value: "housebound",            label: "🏠 Housebound",               sub: "Unable to leave home independently" },
];

const LIVING_OPTIONS = [
  { value: "alone",        label: "👤 Lives alone" },
  { value: "with_partner", label: "👫 With partner" },
  { value: "with_family",  label: "👨‍👩‍👧 With family" },
  { value: "care_home",    label: "🏡 Care home" },
];

export default function ConditionsSection() {
  const [, setLocation] = useLocation();
  const [selectedCat, setSelectedCat] = useState("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [mobility, setMobility] = useState("");
  const [living, setLiving] = useState("");
  const [loading, setLoading] = useState(false);

  const toggleCondition = (name: string) => {
    setSelected((prev) =>
      prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name]
    );
  };

  const removeSelected = (name: string) => setSelected((prev) => prev.filter((x) => x !== name));

  const visibleGroups = CONDITION_GROUPS.filter((g) => {
    if (selectedCat !== "all" && g.cat !== selectedCat) return false;
    if (search) return g.items.some((i) => i.toLowerCase().includes(search.toLowerCase()));
    return true;
  });

  const getVisibleItems = (items: string[]) => {
    if (!search) return items;
    return items.filter((i) => i.toLowerCase().includes(search.toLowerCase()));
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const conditions = selected.map((name) => {
        const group = CONDITION_GROUPS.find((g) => g.items.includes(name));
        return { name, category: group?.cat || "other" };
      });
      await fetch("/api/onboarding/section/conditions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conditions, mobility_level: mobility || null, living_situation: living || null, allergies: [] }),
      });
      setLocation("/onboarding/complete/conditions");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="❤️ Health conditions" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">❤️ Health conditions</h2>
          <p className="text-xs text-gray-500 mt-1">Select everything that applies. Tap again to remove.</p>
        </div>

        {/* Search */}
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">🔍</span>
          <input
            className="w-full pl-9 pr-3 py-2 text-sm border border-purple-200 rounded-lg focus:outline-none focus:border-[#6b21a8]"
            placeholder="Search conditions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {/* Category filter */}
        <CategoryFilterBar categories={CATEGORIES} selected={selectedCat} onChange={setSelectedCat} />

        {/* Selected bar */}
        <div className="bg-purple-50 rounded-lg px-3 py-2 min-h-[36px] flex flex-wrap gap-1.5 items-center">
          {selected.length === 0 ? (
            <span className="text-xs text-purple-400 italic">Nothing selected — tap any condition below</span>
          ) : (
            selected.map((name) => (
              <span key={name} className="inline-flex items-center gap-1 bg-[#6b21a8] text-white text-[10px] px-2 py-0.5 rounded-full">
                {name}
                <button onClick={() => removeSelected(name)} className="opacity-70 hover:opacity-100">×</button>
              </span>
            ))
          )}
        </div>

        {/* Condition groups */}
        {visibleGroups.map((group) => {
          const items = getVisibleItems(group.items);
          if (items.length === 0) return null;
          return (
            <div key={group.cat}>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-2">{group.label}</p>
              <div className="flex flex-wrap gap-1.5">
                {items.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => toggleCondition(item)}
                    className={cn(
                      "inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full border text-[11px] transition-all",
                      selected.includes(item)
                        ? "bg-[#6b21a8] text-white border-[#6b21a8] font-semibold"
                        : "bg-white text-gray-600 border-purple-200 hover:border-[#6b21a8] hover:bg-purple-50"
                    )}
                  >
                    {selected.includes(item) && <span className="w-1 h-1 rounded-full bg-white" />}
                    {item}
                  </button>
                ))}
              </div>
            </div>
          );
        })}

        {/* Mobility */}
        <div>
          <p className="text-xs font-bold text-gray-600 mb-2">Mobility</p>
          <div className="flex flex-col gap-2">
            {MOBILITY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setMobility(opt.value)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg border text-sm font-semibold text-left transition-all",
                  mobility === opt.value ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
                )}
              >
                <span className="flex-1">{opt.label}</span>
                <span className={cn("w-3.5 h-3.5 rounded-full border-2 flex-shrink-0",
                  mobility === opt.value ? "border-[#6b21a8] bg-[#6b21a8] shadow-[inset_0_0_0_2px_white]" : "border-purple-200"
                )} />
              </button>
            ))}
          </div>
        </div>

        {/* Living situation */}
        <div>
          <p className="text-xs font-bold text-gray-600 mb-2">Living situation</p>
          <div className="grid grid-cols-2 gap-2">
            {LIVING_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setLiving(opt.value)}
                className={cn(
                  "py-3 px-2 rounded-lg border text-xs font-bold text-center transition-all",
                  living === opt.value ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save health conditions"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">
            Skip for now
          </button>
        </div>
      </div>
    </PhoneFrame>
  );
}
