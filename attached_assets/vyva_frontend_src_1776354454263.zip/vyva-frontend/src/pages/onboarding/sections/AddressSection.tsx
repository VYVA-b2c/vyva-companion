// src/pages/onboarding/sections/AddressSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AddressSection() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    address_line_1: "", address_line_2: "", city: "",
    region: "", postcode: "", country: "Spain",
  });
  const [loading, setLoading] = useState(false);

  const set = (field: string, value: string) => setForm((prev) => ({ ...prev, [field]: value }));

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/address", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setLocation("/onboarding/complete/address");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="🏠 Home address" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🏠 Home address</h2>
          <p className="text-xs text-gray-500 mt-1">Used for safety features and local concierge services. Shared with emergency services only if you need urgent help.</p>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Address line 1</Label>
          <Input placeholder="Street and house / flat number" value={form.address_line_1} onChange={(e) => set("address_line_1", e.target.value)} className="h-11 border-purple-200" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-bold text-gray-600">Address line 2 (optional)</Label>
          <Input placeholder="Floor, building name" value={form.address_line_2} onChange={(e) => set("address_line_2", e.target.value)} className="h-11 border-purple-200" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">City / Town</Label>
            <Input placeholder="e.g. Zamora" value={form.city} onChange={(e) => set("city", e.target.value)} className="h-11 border-purple-200" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Postcode</Label>
            <Input placeholder="e.g. 49001" value={form.postcode} onChange={(e) => set("postcode", e.target.value)} className="h-11 border-purple-200" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Region / Province</Label>
            <Input placeholder="e.g. Castilla y León" value={form.region} onChange={(e) => set("region", e.target.value)} className="h-11 border-purple-200" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Country</Label>
            <Select defaultValue="Spain" onValueChange={(v) => set("country", v)}>
              <SelectTrigger className="h-11 border-purple-200"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Spain">Spain</SelectItem>
                <SelectItem value="Germany">Germany</SelectItem>
                <SelectItem value="United Kingdom">United Kingdom</SelectItem>
                <SelectItem value="France">France</SelectItem>
                <SelectItem value="Italy">Italy</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]">
            {loading ? "Saving..." : "Save home address"}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
