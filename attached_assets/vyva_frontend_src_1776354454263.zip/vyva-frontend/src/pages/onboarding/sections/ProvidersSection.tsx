// src/pages/onboarding/sections/ProvidersSection.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  "Taxi / Transport","Pharmacy","Hairdresser / Barber","Cleaner / Home help",
  "Gardener","Plumber","Electrician","Dentist","Optician","Physiotherapist",
  "Restaurant / Delivery","Other",
];

// Simulated Places result for demo — replace with real @googlemaps/js-api-loader in production
const MOCK_RESULTS = [
  { place_id: "p1", name: "Farmacia López",     address: "Calle de la Reina 14, Zamora, 49001", phone: "+34 980 512 034" },
  { place_id: "p2", name: "Farmacia del Centro", address: "Plaza Mayor 3, Zamora, 49001",         phone: "+34 980 531 200" },
  { place_id: "p3", name: "Farmacia San Frontis", address: "Av. de Requejo 22, Zamora, 49001",   phone: "+34 980 520 100" },
];

interface Provider {
  category: string;
  name: string;
  phone: string;
  full_address: string;
  google_place_id: string;
  google_maps_url: string;
  notes: string;
  source: "google_places" | "manual";
}

export default function ProvidersSection() {
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState<"search" | "manual">("search");
  const [category, setCategory] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState<typeof MOCK_RESULTS[0] | null>(null);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [notes, setNotes] = useState("");
  const [manualForm, setManualForm] = useState({ name: "", phone: "", address_line_1: "", city: "", postcode: "", notes: "", maps_url: "" });
  const [loading, setLoading] = useState(false);

  const setM = (f: string, v: string) => setManualForm((p) => ({ ...p, [f]: v }));

  const handleSelectPlace = (place: typeof MOCK_RESULTS[0]) => {
    setSelectedPlace(place);
    setShowResults(false);
    setSearchQuery("");
  };

  const handleAddProvider = () => {
    if (!selectedPlace || !category) return;
    setProviders((prev) => [...prev, {
      category: category.toLowerCase().replace(/ \/ /g, "_").replace(/ /g, "_"),
      name: selectedPlace.name,
      phone: selectedPlace.phone,
      full_address: selectedPlace.address,
      google_place_id: selectedPlace.place_id,
      google_maps_url: `https://maps.google.com/?place_id=${selectedPlace.place_id}`,
      notes,
      source: "google_places",
    }]);
    setSelectedPlace(null);
    setNotes("");
    setCategory("");
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await fetch("/api/onboarding/section/providers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ providers }),
      });
      setLocation("/onboarding/complete/providers");
    } finally { setLoading(false); }
  };

  return (
    <PhoneFrame subtitle="🔑 Trusted providers" showBack onBack={() => setLocation("/onboarding/profile")} showAllSections onAllSections={() => setLocation("/onboarding/profile")}>
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">🔑 Trusted providers</h2>
          <p className="text-xs text-gray-500 mt-1">Your personal directory. VYVA uses these first when you ask for transport, repairs, or deliveries.</p>
        </div>

        <div className="bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-3 py-2 text-xs text-purple-700">
          VYVA will always ask before contacting any provider on your behalf.
        </div>

        {/* Added providers */}
        {providers.map((p, i) => (
          <div key={i} className="flex items-center gap-3 px-3 py-2.5 border border-green-200 bg-green-50 rounded-lg">
            <span className="text-green-600 font-bold text-sm">✓</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-gray-900">{p.name}</p>
              <p className="text-[10px] text-gray-500 truncate">{p.full_address}</p>
            </div>
            <button onClick={() => setProviders((prev) => prev.filter((_, j) => j !== i))} className="text-xs text-gray-400 hover:text-red-500">✕</button>
          </div>
        ))}

        {/* Mode tabs */}
        <div className="flex gap-2">
          {(["search","manual"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={cn("flex-1 text-center py-2 text-xs font-bold rounded-lg border transition-all",
                tab === t ? "border-[#6b21a8] bg-purple-100 text-purple-700" : "border-purple-100 bg-white text-gray-500 hover:border-purple-200"
              )}>
              {t === "search" ? "🔍 Search Google Places" : "✏️ Add manually"}
            </button>
          ))}
        </div>

        {tab === "search" && (
          <div className="flex flex-col gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-gray-600">Category</Label>
              <Select onValueChange={setCategory}>
                <SelectTrigger className="h-11 border-purple-200"><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {!selectedPlace ? (
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">🔍</span>
                <input
                  className="w-full pl-9 pr-3 py-2.5 text-sm border border-purple-200 rounded-lg focus:outline-none focus:border-[#6b21a8]"
                  placeholder="Type name or address..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setShowResults(e.target.value.length > 1); }}
                />
                <p className="text-[10px] text-gray-400 text-center mt-1">Powered by Google Places</p>
                {showResults && (
                  <div className="border border-purple-100 rounded-xl overflow-hidden mt-1 bg-white shadow-sm">
                    {MOCK_RESULTS.map((r) => (
                      <button key={r.place_id} onClick={() => handleSelectPlace(r)}
                        className="w-full flex items-start gap-3 px-3 py-2.5 border-b border-purple-50 last:border-0 hover:bg-purple-50 text-left transition-colors">
                        <span className="text-base mt-0.5">💊</span>
                        <div>
                          <p className="text-sm font-bold text-gray-900">{r.name}</p>
                          <p className="text-[10px] text-gray-500">{r.address}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="border-2 border-[#6b21a8] rounded-xl p-3 bg-purple-50 flex flex-col gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center text-lg">💊</div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-gray-900">{selectedPlace.name}</p>
                    <p className="text-[10px] text-purple-600">Pharmacy</p>
                  </div>
                  <button onClick={() => setSelectedPlace(null)} className="text-xs text-gray-400 hover:text-gray-600">Change</button>
                </div>
                <p className="text-xs text-gray-600 flex gap-2"><span>📍</span>{selectedPlace.address}</p>
                <p className="text-xs text-gray-600 flex gap-2"><span>📞</span>{selectedPlace.phone}</p>
                <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-1.5">
                  <span>🗺️</span>
                  <span className="text-xs text-green-700 font-bold flex-1">Google Maps link saved</span>
                  <button className="text-[10px] border border-green-300 bg-white text-green-700 rounded px-2 py-0.5">Open ↗</button>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs font-bold text-gray-600">Notes (optional)</Label>
                  <Input placeholder="e.g. Ask for Rosa, open Mon–Sat" value={notes} onChange={(e) => setNotes(e.target.value)} className="h-10 border-purple-200 text-sm" />
                </div>
                <Button onClick={handleAddProvider} disabled={!category} variant="outline" className="w-full h-10 text-sm font-bold border-[#6b21a8] text-[#6b21a8]">
                  + Add to my directory
                </Button>
              </div>
            )}
          </div>
        )}

        {tab === "manual" && (
          <div className="border border-purple-100 rounded-xl p-4 bg-white flex flex-col gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-gray-600">Category</Label>
              <Select onValueChange={(v) => setM("category", v)}>
                <SelectTrigger className="h-11 border-purple-200"><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {[
              { f:"name",          l:"Name",           p:"e.g. Taxi Miguel" },
              { f:"phone",         l:"Phone number",   p:"", t:"tel" },
              { f:"address_line_1",l:"Address",        p:"Street and number" },
              { f:"city",          l:"City",           p:"e.g. Zamora" },
              { f:"postcode",      l:"Postcode",       p:"e.g. 49001" },
              { f:"maps_url",      l:"Google Maps URL (optional)", p:"https://maps.app.goo.gl/..." },
              { f:"notes",         l:"Notes (optional)", p:"e.g. Ask for Pedro, Mon–Fri only" },
            ].map(({ f, l, p, t }) => (
              <div key={f} className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-600">{l}</Label>
                <Input type={t || "text"} placeholder={p} value={(manualForm as any)[f]} onChange={(e) => setM(f, e.target.value)} className="h-11 border-purple-200" />
              </div>
            ))}
          </div>
        )}

        <button className="text-sm font-bold text-[#6b21a8] text-left">+ Add another provider</button>

        <div className="flex flex-col gap-2 pt-2">
          <Button onClick={handleSave} disabled={loading || providers.length === 0} className="w-full h-12 font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40">
            {loading ? "Saving..." : `Save providers (${providers.length})`}
          </Button>
          <button onClick={() => setLocation("/onboarding/profile")} className="text-xs text-gray-400 py-2 text-center">Skip for now</button>
        </div>
      </div>
    </PhoneFrame>
  );
}
