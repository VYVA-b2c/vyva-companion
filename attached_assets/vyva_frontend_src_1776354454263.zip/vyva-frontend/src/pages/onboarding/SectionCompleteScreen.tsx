// src/pages/onboarding/SectionCompleteScreen.tsx
// Shown after saving any section — displays unlock card + next section CTA

import { useLocation, useParams } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";

const SECTIONS = [
  { id: "medications", title: "Medications",         unlock: "Medication reminders + interaction checks" },
  { id: "conditions",  title: "Health conditions",   unlock: "Health coaching + personalised nutrition" },
  { id: "cognitive",   title: "Cognitive profile",   unlock: "Personalised brain training + communication style" },
  { id: "diet",        title: "Dietary preferences", unlock: "Personalised nutrition coaching" },
  { id: "address",     title: "Home address",        unlock: "Safety features + local concierge services" },
  { id: "gp",          title: "GP / Doctor",         unlock: "Appointment prep + health referrals" },
  { id: "devices",     title: "Devices & sensors",   unlock: "Richer triage + symptom reports" },
  { id: "hobbies",     title: "Hobbies & interests", unlock: "Personalised daily conversations" },
  { id: "careteam",    title: "Care team",           unlock: "Safety alerts + family dashboard access" },
  { id: "providers",   title: "Trusted providers",   unlock: "VYVA uses your preferred services first" },
  { id: "emergency",   title: "Emergency contact",   unlock: "Emergency response + location sharing" },
];

export default function SectionCompleteScreen() {
  const [, setLocation] = useLocation();
  const { id } = useParams<{ id: string }>();

  const current = SECTIONS.find((s) => s.id === id);
  const currentIdx = SECTIONS.findIndex((s) => s.id === id);
  const next = SECTIONS[currentIdx + 1];

  return (
    <PhoneFrame>
      <div className="flex flex-col items-center gap-5 px-5 py-10 text-center">
        <div className="w-14 h-14 rounded-full bg-green-50 border-2 border-green-200 flex items-center justify-center text-3xl">
          ✅
        </div>

        <div>
          <h2 className="text-xl font-bold text-gray-900">{current?.title} done!</h2>
          <p className="text-sm text-gray-500 mt-1">Here's what just unlocked:</p>
        </div>

        {/* Unlock card */}
        <div className="w-full bg-purple-50 rounded-xl px-4 py-3 text-left">
          <p className="text-[10px] font-bold text-purple-700 mb-1">🔓 Now unlocked</p>
          <p className="text-sm text-purple-800">{current?.unlock}</p>
        </div>

        <div className="w-full flex flex-col gap-3 mt-2">
          {next && (
            <Button
              onClick={() => setLocation(`/onboarding/profile/${next.id === "careteam" ? "careteam" : next.id}`)}
              className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]"
            >
              Continue — {next.title}
            </Button>
          )}
          <Button
            variant="outline"
            onClick={() => setLocation("/onboarding/profile")}
            className="w-full h-12 text-sm font-bold border-[#6b21a8] text-[#6b21a8] hover:bg-purple-50"
          >
            See all sections
          </Button>
          <button
            onClick={() => setLocation("/app")}
            className="text-xs text-gray-400 py-2"
          >
            I'm done for now — talk to VYVA
          </button>
        </div>
      </div>
    </PhoneFrame>
  );
}
