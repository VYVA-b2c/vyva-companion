// src/pages/onboarding/ProfileOverview.tsx
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { SectionCard } from "@/components/onboarding/SectionCard";
import { Button } from "@/components/ui/button";

const SECTIONS = [
  { id: "medications", emoji: "💊", title: "Medications",         subtitle: "Medication reminders + interaction checks", bg: "#fef3c7" },
  { id: "conditions",  emoji: "❤️", title: "Health conditions",   subtitle: "Health coaching + personalised nutrition",   bg: "#fce7f3" },
  { id: "cognitive",   emoji: "🧠", title: "Cognitive profile",   subtitle: "Brain training + communication style",       bg: "#e1f5ee" },
  { id: "diet",        emoji: "🥗", title: "Dietary preferences", subtitle: "Personalised nutrition coaching",            bg: "#dcfce7" },
  { id: "address",     emoji: "🏠", title: "Home address",        subtitle: "Safety + local concierge services",          bg: "#e1f5ee" },
  { id: "gp",          emoji: "🏥", title: "GP / Doctor",         subtitle: "Appointment prep + health referrals",        bg: "#e6f1fb" },
  { id: "devices",     emoji: "📡", title: "Devices & sensors",   subtitle: "Richer triage + symptom reports",            bg: "#dbeafe" },
  { id: "hobbies",     emoji: "⭐", title: "Hobbies & interests",  subtitle: "Personalised daily conversations",          bg: "#faeeda" },
  { id: "careteam",    emoji: "👥", title: "Care team",           subtitle: "Safety alerts + family dashboard",           bg: "#ede9fe" },
  { id: "providers",   emoji: "🔑", title: "Trusted providers",   subtitle: "VYVA uses your preferred services first",    bg: "#fef3c7" },
  { id: "emergency",   emoji: "🆘", title: "Emergency contact",   subtitle: "Emergency response + location sharing",      bg: "#fee2e2" },
];

export default function ProfileOverview() {
  const [, setLocation] = useLocation();
  const [done, setDone] = useState<Record<string, boolean>>({});

  useEffect(() => {
    // Load current onboarding state from API
    fetch("/api/onboarding/state")
      .then((r) => r.json())
      .then((data) => {
        const state = data.onboardingState || {};
        const computed: Record<string, boolean> = {
          medications: state.has_medications,
          conditions:  state.has_health_conditions,
          cognitive:   state.has_cognitive_profile,
          diet:        state.has_dietary_prefs,
          address:     state.has_emergency_address,
          gp:          state.has_gp_details,
          devices:     state.has_devices,
          hobbies:     state.has_hobbies,
          careteam:    state.has_caregiver || state.has_family_member || state.has_doctor,
          providers:   state.has_trusted_providers,
          emergency:   state.has_emergency_contact,
        };
        setDone(computed);
      })
      .catch(() => {});
  }, []);

  const completedCount = Object.values(done).filter(Boolean).length;
  const progress = Math.round((completedCount / SECTIONS.length) * 100);

  const handleSection = (id: string) => {
    if (id === "careteam") {
      setLocation("/onboarding/careteam");
    } else {
      setLocation(`/onboarding/profile/${id}`);
    }
  };

  return (
    <PhoneFrame
      subtitle="My profile"
      progress={progress}
      progressLabel={`${completedCount} of ${SECTIONS.length}`}
    >
      <div className="flex flex-col gap-4 px-4 py-5">
        <div>
          <h2 className="text-xl font-bold text-gray-900">My profile</h2>
          <p className="text-sm text-gray-500 mt-1">Each section unlocks more features. No rush.</p>
        </div>

        {/* Progress bar */}
        <div>
          <div className="bg-purple-100 rounded-full h-2">
            <div
              className="bg-[#6b21a8] h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-[10px] text-gray-400 text-right mt-1">
            {completedCount} of {SECTIONS.length} sections complete
          </p>
        </div>

        {/* Section cards */}
        <div className="flex flex-col gap-2">
          {SECTIONS.map((s) => (
            <SectionCard
              key={s.id}
              emoji={s.emoji}
              title={s.title}
              subtitle={done[s.id] ? "Done — tap to edit" : `Unlocks: ${s.subtitle}`}
              done={!!done[s.id]}
              onClick={() => handleSection(s.id)}
              bg={s.bg}
            />
          ))}
        </div>

        {/* Settings link */}
        <Button
          variant="outline"
          onClick={() => setLocation("/app/settings")}
          className="w-full mt-2 border-purple-200 text-purple-700 hover:bg-purple-50"
        >
          ⚙️ Settings
        </Button>
      </div>
    </PhoneFrame>
  );
}
