// src/pages/onboarding/WelcomeScreen.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Path = "self" | "family";

export default function WelcomeScreen() {
  const [, setLocation] = useLocation();
  const [path, setPath] = useState<Path>("self");

  const handleContinue = () => {
    if (path === "self") {
      setLocation("/onboarding/basics");
    } else {
      setLocation("/onboarding/family");
    }
  };

  return (
    <PhoneFrame>
      <div className="flex flex-col gap-5 px-5 py-8 min-h-full">
        {/* Hero */}
        <div className="text-center pt-4 pb-2">
          <div className="text-5xl mb-4">👋</div>
          <h1 className="text-2xl font-bold text-gray-900">Hello! Let's get started</h1>
          <p className="text-sm text-gray-500 mt-2 leading-relaxed">
            VYVA is your AI companion for daily life. Getting started takes about 2 minutes.
          </p>
        </div>

        {/* Path selection */}
        <div className="flex flex-col gap-3 mt-2">
          <PathCard
            emoji="👤"
            title="For myself"
            subtitle="I want to use VYVA"
            bg="#ede9fe"
            selected={path === "self"}
            onSelect={() => setPath("self")}
          />
          <PathCard
            emoji="💚"
            title="For someone I care about"
            subtitle="Setting this up for a family member or friend"
            bg="#e1f5ee"
            selected={path === "family"}
            onSelect={() => setPath("family")}
          />
        </div>

        <div className="mt-auto pt-4">
          <Button
            onClick={handleContinue}
            className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f]"
          >
            Continue
          </Button>
        </div>
      </div>
    </PhoneFrame>
  );
}

function PathCard({
  emoji, title, subtitle, bg, selected, onSelect,
}: {
  emoji: string;
  title: string;
  subtitle: string;
  bg: string;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex items-start gap-3 p-4 rounded-xl border-2 text-left transition-all",
        selected ? "border-[#6b21a8] bg-purple-50" : "border-purple-100 bg-white hover:border-purple-200"
      )}
    >
      <div
        className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-xl"
        style={{ background: bg }}
      >
        {emoji}
      </div>
      <div>
        <p className="text-sm font-bold text-gray-900">{title}</p>
        <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{subtitle}</p>
      </div>
    </button>
  );
}
