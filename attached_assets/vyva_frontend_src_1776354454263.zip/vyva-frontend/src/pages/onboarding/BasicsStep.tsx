// src/pages/onboarding/BasicsStep.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function BasicsStep() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    full_name: "",
    preferred_name: "",
    phone_number: "",
    language: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const isValid = form.full_name.trim() && form.phone_number.trim() && form.language;

  const handleSubmit = async () => {
    if (!isValid) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/onboarding/basics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          preferred_name: form.preferred_name || form.full_name.split(" ")[0],
          onboarding_channel: "web_form",
        }),
      });
      if (!res.ok) throw new Error("Failed to save");
      setLocation("/onboarding/channel");
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="Step 1 of 3 — The basics" progress={10} showBack onBack={() => setLocation("/")}>
      <div className="flex flex-col gap-5 px-5 py-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900">The basics</h2>
          <p className="text-sm text-gray-500 mt-1">
            Three things and you're ready to talk to VYVA.
          </p>
        </div>

        <div className="flex flex-col gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="full_name" className="text-xs font-bold text-gray-600">Your full name</Label>
            <Input
              id="full_name"
              placeholder="e.g. María García López"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              className="h-11 text-base border-purple-200 focus:border-[#6b21a8]"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="preferred_name" className="text-xs font-bold text-gray-600">
              What would you like VYVA to call you?
            </Label>
            <Input
              id="preferred_name"
              placeholder="e.g. María, Mrs García..."
              value={form.preferred_name}
              onChange={(e) => setForm({ ...form, preferred_name: e.target.value })}
              className="h-11 text-base border-purple-200 focus:border-[#6b21a8]"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="phone" className="text-xs font-bold text-gray-600">Your phone number</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="e.g. +34 612 345 678"
              value={form.phone_number}
              onChange={(e) => setForm({ ...form, phone_number: e.target.value })}
              className="h-11 text-base border-purple-200 focus:border-[#6b21a8]"
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs font-bold text-gray-600">Preferred language</Label>
            <Select onValueChange={(v) => setForm({ ...form, language: v })}>
              <SelectTrigger className="h-11 text-base border-purple-200">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="de">Deutsch</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {error && (
          <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>
        )}

        <div className="mt-auto pt-2">
          <Button
            onClick={handleSubmit}
            disabled={!isValid || loading}
            className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40"
          >
            {loading ? "Saving..." : "Continue ✓"}
          </Button>
        </div>
      </div>
    </PhoneFrame>
  );
}
