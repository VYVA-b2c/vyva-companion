// src/pages/onboarding/DataConsentStep.tsx
import { useState } from "react";
import { useLocation } from "wouter";
import { PhoneFrame } from "@/components/onboarding/PhoneFrame";
import { ToggleRow } from "@/components/onboarding/ToggleRow";
import { Button } from "@/components/ui/button";

export default function DataConsentStep() {
  const [, setLocation] = useLocation();
  const [requiredConsent, setRequiredConsent] = useState(false);
  const [improvementConsent, setImprovementConsent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleContinue = async () => {
    if (!requiredConsent) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/onboarding/consent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          required_consent: requiredConsent,
          improvement_consent: improvementConsent,
        }),
      });
      if (!res.ok) throw new Error("Failed to record consent");
      setLocation("/onboarding/activation");
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame subtitle="Step 3 of 3 — Privacy" progress={70} showBack onBack={() => setLocation("/onboarding/channel")}>
      <div className="flex flex-col gap-5 px-5 py-6">
        {/* Header */}
        <div className="text-center py-2">
          <div className="text-4xl mb-3">🔒</div>
          <h2 className="text-xl font-bold text-gray-900">Your privacy, your control</h2>
          <p className="text-sm text-gray-500 mt-2 leading-relaxed">
            Before you meet VYVA, we need your consent. Please read carefully.
          </p>
        </div>

        {/* What VYVA collects */}
        <div className="bg-purple-50 border-l-2 border-[#6b21a8] rounded-lg px-4 py-3 text-xs text-purple-800 leading-relaxed space-y-2">
          <div>
            <p className="font-bold mb-1">What VYVA collects</p>
            <ul className="space-y-0.5 list-none">
              <li>• Your name, phone, and language</li>
              <li>• Health information you choose to share</li>
              <li>• Conversation history to personalise your experience</li>
            </ul>
          </div>
          <div>
            <p className="font-bold mb-1">How it's stored</p>
            <p>Securely on EU servers. Encrypted at rest and in transit. Never sold to third parties.</p>
          </div>
          <div>
            <p className="font-bold mb-1">Who can see it</p>
            <p>Only you — and people you explicitly choose to share with.</p>
          </div>
        </div>

        {/* Required consent */}
        <div className="border border-purple-100 rounded-xl px-4 py-1 bg-white">
          <ToggleRow
            title="I agree to VYVA collecting and storing my personal and health information to provide the AI companion service."
            checked={requiredConsent}
            onChange={setRequiredConsent}
          />
          <span className="text-[10px] font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded mb-3 inline-block">
            Required to use VYVA
          </span>
        </div>

        {/* Optional consent */}
        <div className="border border-purple-100 rounded-xl px-4 py-1 bg-white">
          <ToggleRow
            title="I agree to anonymous, aggregated data being used to improve VYVA for all users. No personal information is shared."
            checked={improvementConsent}
            onChange={setImprovementConsent}
          />
          <span className="text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded mb-3 inline-block">
            Optional — you can say no
          </span>
        </div>

        {/* Policy link */}
        <div className="text-center">
          <button className="text-xs text-[#6b21a8] underline">
            Read our full privacy policy →
          </button>
        </div>

        {error && (
          <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>
        )}

        <div className="mt-auto flex flex-col gap-2 pt-2">
          <Button
            onClick={handleContinue}
            disabled={!requiredConsent || loading}
            className="w-full h-12 text-base font-bold bg-[#6b21a8] hover:bg-[#5b1a8f] disabled:opacity-40"
          >
            {loading ? "Saving..." : "I agree — continue"}
          </Button>
          <p className="text-[10px] text-gray-400 text-center">
            You can review privacy settings at any time in Settings → Privacy & consent
          </p>
        </div>
      </div>
    </PhoneFrame>
  );
}
