// src/components/onboarding/ToggleRow.tsx
// Consent / privacy toggle row — used in DataConsent, CareTeamConsent, PrivacySettings

import { cn } from "@/lib/utils";

interface ToggleRowProps {
  title: string;
  description?: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  variant?: "default" | "amber";  // amber = safety alerts (always-on warning colour)
  className?: string;
}

export function ToggleRow({
  title,
  description,
  checked,
  onChange,
  variant = "default",
  className,
}: ToggleRowProps) {
  return (
    <div className={cn("flex items-start gap-3 py-3", className)}>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-gray-900 leading-snug">{title}</p>
        {description && (
          <p className="text-xs text-gray-500 mt-1 leading-relaxed">{description}</p>
        )}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative flex-shrink-0 w-10 h-[22px] rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2",
          checked
            ? variant === "amber"
              ? "bg-[#c9890a] focus:ring-[#c9890a]"
              : "bg-[#6b21a8] focus:ring-[#6b21a8]"
            : "bg-purple-200 focus:ring-purple-300"
        )}
      >
        <span
          className={cn(
            "absolute top-[3px] left-[3px] w-4 h-4 rounded-full bg-white shadow-sm transition-transform duration-200",
            checked ? "translate-x-[18px]" : "translate-x-0"
          )}
        />
      </button>
    </div>
  );
}
