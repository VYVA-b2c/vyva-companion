// src/components/onboarding/PhoneFrame.tsx
// Purple header wrapper with progress bar — wraps every onboarding screen

interface PhoneFrameProps {
  subtitle?: string;
  progress?: number;       // 0–100
  progressLabel?: string;  // e.g. "2 of 11 sections"
  showBack?: boolean;
  showAllSections?: boolean;
  onBack?: () => void;
  onAllSections?: () => void;
  children: React.ReactNode;
}

export function PhoneFrame({
  subtitle,
  progress,
  progressLabel,
  showBack = false,
  showAllSections = false,
  onBack,
  onAllSections,
  children,
}: PhoneFrameProps) {
  return (
    <div className="flex flex-col min-h-screen bg-[#f5f3f8]">
      {/* Purple header */}
      <div className="bg-[#6b21a8] px-5 pt-12 pb-4 flex-shrink-0">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-white text-xl font-bold tracking-tight">VYVA</span>
          {progress !== undefined && (
            <>
              <div className="flex-1 bg-white/25 rounded-full h-1">
                <div
                  className="bg-[#c9890a] h-1 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-white/80 text-[10px] whitespace-nowrap">
                {progressLabel || `${progress}%`}
              </span>
            </>
          )}
        </div>
        {subtitle && (
          <p className="text-white/70 text-xs">{subtitle}</p>
        )}
      </div>

      {/* Back / nav row */}
      {(showBack || showAllSections) && (
        <div className="flex items-center px-4 py-2 bg-white border-b border-purple-50">
          {showBack && (
            <button
              onClick={onBack}
              className="text-xs text-gray-500 hover:text-gray-700 transition-colors"
            >
              ← Back
            </button>
          )}
          {showAllSections && (
            <button
              onClick={onAllSections}
              className="ml-auto text-xs text-gray-500 hover:text-gray-700 transition-colors"
            >
              All sections ›
            </button>
          )}
        </div>
      )}

      {/* Screen content */}
      <div className="flex-1 overflow-y-auto">
        {children}
      </div>
    </div>
  );
}
