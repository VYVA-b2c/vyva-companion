// src/components/onboarding/SectionCard.tsx
// Section card shown in the profile overview grid

import { cn } from "@/lib/utils";

interface SectionCardProps {
  emoji: string;
  title: string;
  subtitle: string;
  done: boolean;
  onClick: () => void;
  bg?: string;
}

export function SectionCard({ emoji, title, subtitle, done, onClick, bg = "#f3f0ff" }: SectionCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-3 rounded-xl border text-left transition-all",
        done
          ? "border-green-200 bg-green-50"
          : "border-purple-100 bg-white hover:border-purple-200"
      )}
    >
      <div
        className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-base"
        style={{ background: bg }}
      >
        {emoji}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[12px] font-bold text-gray-900">{title}</p>
        <p className="text-[10px] text-gray-500 mt-0.5 truncate">{subtitle}</p>
      </div>
      <div className={cn(
        "flex-shrink-0 text-[10px] font-bold",
        done ? "text-green-600 text-sm" : "text-[#c9890a]"
      )}>
        {done ? "✓" : "+ Unlock"}
      </div>
    </button>
  );
}
