// src/components/onboarding/ChipSelector.tsx
// Reusable multi-select chip group used across diet, hobbies, conditions sections

import { cn } from "@/lib/utils";

interface ChipSelectorProps {
  options: string[];
  selected: string[];
  onChange: (selected: string[]) => void;
  className?: string;
}

export function ChipSelector({ options, selected, onChange, className }: ChipSelectorProps) {
  const toggle = (option: string) => {
    if (selected.includes(option)) {
      onChange(selected.filter((s) => s !== option));
    } else {
      onChange([...selected, option]);
    }
  };

  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {options.map((option) => {
        const isSelected = selected.includes(option);
        return (
          <button
            key={option}
            type="button"
            onClick={() => toggle(option)}
            className={cn(
              "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-sm transition-all",
              isSelected
                ? "bg-[#6b21a8] text-white border-[#6b21a8] font-semibold"
                : "bg-white text-gray-600 border-purple-200 hover:border-[#6b21a8] hover:text-purple-700 hover:bg-purple-50"
            )}
          >
            {isSelected && (
              <span className="w-1.5 h-1.5 rounded-full bg-white flex-shrink-0" />
            )}
            {option}
          </button>
        );
      })}
    </div>
  );
}
