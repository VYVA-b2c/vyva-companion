// src/components/onboarding/CategoryFilterBar.tsx
// Horizontal scrollable category filter bar — used in health conditions section

import { cn } from "@/lib/utils";

interface Category {
  id: string;
  label: string;
}

interface CategoryFilterBarProps {
  categories: Category[];
  selected: string;
  onChange: (id: string) => void;
}

export function CategoryFilterBar({ categories, selected, onChange }: CategoryFilterBarProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none -mx-4 px-4">
      {categories.map((cat) => (
        <button
          key={cat.id}
          type="button"
          onClick={() => onChange(cat.id)}
          className={cn(
            "flex-shrink-0 text-[10px] font-bold px-3 py-1.5 rounded-full border transition-all whitespace-nowrap",
            selected === cat.id
              ? "bg-[#6b21a8] text-white border-[#6b21a8]"
              : "bg-white text-gray-500 border-purple-100 hover:border-purple-300"
          )}
        >
          {cat.label}
        </button>
      ))}
    </div>
  );
}
