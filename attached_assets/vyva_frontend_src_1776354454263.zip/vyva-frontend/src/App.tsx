// src/App.tsx
// Main router — add this to your existing App.tsx or merge the routes in
// Uses Wouter for routing (already in the project)

import { Route, Switch } from "wouter";

// Onboarding pages
import WelcomeScreen        from "@/pages/onboarding/WelcomeScreen";
import BasicsStep           from "@/pages/onboarding/BasicsStep";
import ChannelStep          from "@/pages/onboarding/ChannelStep";
import DataConsentStep      from "@/pages/onboarding/DataConsentStep";
import ActivationStep       from "@/pages/onboarding/ActivationStep";
import ProfileOverview      from "@/pages/onboarding/ProfileOverview";
import SectionCompleteScreen from "@/pages/onboarding/SectionCompleteScreen";

// Sections
import MedicationsSection   from "@/pages/onboarding/sections/MedicationsSection";
import ConditionsSection    from "@/pages/onboarding/sections/ConditionsSection";
import CognitiveSection     from "@/pages/onboarding/sections/CognitiveSection";
import DietSection          from "@/pages/onboarding/sections/DietSection";
import AddressSection       from "@/pages/onboarding/sections/AddressSection";
import GPSection            from "@/pages/onboarding/sections/GPSection";
import DevicesSection       from "@/pages/onboarding/sections/DevicesSection";
import HobbiesSection       from "@/pages/onboarding/sections/HobbiesSection";
import ProvidersSection     from "@/pages/onboarding/sections/ProvidersSection";
import EmergencySection     from "@/pages/onboarding/sections/EmergencySection";
import CareTeamFlow         from "@/pages/onboarding/sections/CareTeamFlow";

// Settings
import SettingsHome         from "@/pages/settings/SettingsHome";
import AccountSettings      from "@/pages/settings/AccountSettings";
import NotificationsSettings from "@/pages/settings/NotificationsSettings";
import PrivacySettings      from "@/pages/settings/PrivacySettings";
import SubscriptionSettings from "@/pages/settings/SubscriptionSettings";

// Section ID → component map
const SECTION_COMPONENTS: Record<string, React.ComponentType> = {
  medications:  MedicationsSection,
  conditions:   ConditionsSection,
  cognitive:    CognitiveSection,
  diet:         DietSection,
  address:      AddressSection,
  gp:           GPSection,
  devices:      DevicesSection,
  hobbies:      HobbiesSection,
  providers:    ProvidersSection,
  emergency:    EmergencySection,
};

function SectionRouter({ params }: { params: { id: string } }) {
  const Component = SECTION_COMPONENTS[params.id];
  if (!Component) return <div className="p-8 text-center text-gray-500">Section not found</div>;
  return <Component />;
}

export default function App() {
  return (
    <Switch>
      {/* Welcome / path selection */}
      <Route path="/"                             component={WelcomeScreen} />

      {/* Path A — elder onboarding */}
      <Route path="/onboarding/basics"            component={BasicsStep} />
      <Route path="/onboarding/channel"           component={ChannelStep} />
      <Route path="/onboarding/consent"           component={DataConsentStep} />
      <Route path="/onboarding/activation"        component={ActivationStep} />
      <Route path="/onboarding/profile"           component={ProfileOverview} />
      <Route path="/onboarding/profile/:id"       component={SectionRouter} />
      <Route path="/onboarding/careteam"          component={CareTeamFlow} />
      <Route path="/onboarding/complete/:id"      component={SectionCompleteScreen} />

      {/* Settings */}
      <Route path="/app/settings"                 component={SettingsHome} />
      <Route path="/app/settings/account"         component={AccountSettings} />
      <Route path="/app/settings/notifications"   component={NotificationsSettings} />
      <Route path="/app/settings/privacy"         component={PrivacySettings} />
      <Route path="/app/settings/subscription"    component={SubscriptionSettings} />

      {/* Fallback */}
      <Route>
        <div className="flex items-center justify-center min-h-screen text-gray-400">
          <p>Page not found</p>
        </div>
      </Route>
    </Switch>
  );
}
